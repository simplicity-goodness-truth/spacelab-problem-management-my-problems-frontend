/* global QUnit */

sap.ui.require([
	"zslpmmyprb/test/integration/AllJourneys"
], function() {
	QUnit.config.autostart = false;
	QUnit.start();
});